#include<iostream>
#include<math.h>
using namespace std;
struct Diem2D
{
	int x, y;
};
struct DTron {
	Diem2D I;
	int r;
};

struct Array {
	DTron dsdt[100];
	int n;
};
void Nhap(DTron& dt);
void Xuat(DTron dt);
float dienTich(DTron dt);
float chuVi(DTron dt);
void nhapDiemA(Diem2D& a);
void xuatDiemA(Diem2D& a);
float doDai(Diem2D a, DTron dt);
void tuongQuan(Diem2D a, DTron dt);
void NhapArray(Array& ds);
void XuatArray(Array ds);
void Swap(DTron& a, DTron& b);
void SortA(Array ds);



