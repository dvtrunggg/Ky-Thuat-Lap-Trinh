#include"Diem2D.h"

int main()
{
	DTron dt;
	Nhap(dt);
	Xuat(dt);
	cout << "\nDtich = " << dienTich(dt) << endl;
	cout << "\nChu vi = " << chuVi(dt) << endl;
	Diem2D a;
	cout << "\nNhap toa do A"<<endl;
	nhapDiemA(a);
	tuongQuan(a, dt);

	Array ds;
	NhapArray(ds);
	XuatArray(ds);
	/*cout << "Sap xep tang dan theo dien tich: " << endl;
	SortA(ds);
	XuatArray(ds);*/
	return 0;
}
