﻿#include "Diem2D.h"

const float pi = 3.14;

void Nhap(DTron& dt)
{
	cout << "Nhap toa do tam I: "<<endl;
	cout << "Nhap x:", cin >> dt.I.x;
	cout << "Nhap y:", cin >> dt.I.y;
	cout << "Nhap ban kinh: ", cin >> dt.r;
}
void Xuat(DTron dt)
{
	cout << "I(" << dt.I.x << ", " << dt.I.y << ")" << endl;
	cout << "r = " << dt.r;
}
float dienTich(DTron dt)
{
	return pi * dt.r * dt.r;
}
float chuVi(DTron dt)
{
	return 2 * dt.r * pi;
}
void nhapDiemA(Diem2D &a)
{
	cout << "Nhap x:", cin >> a.x;
	cout << "Nhap y:", cin >> a.y;
}
void xuatDiemA(Diem2D& a)
{
	cout << "A(" << a.x << ", " << a.y << ")" << endl;
}
float doDai(Diem2D a, DTron dt)
{
	Diem2D vector;
	vector.x = a.x - dt.I.x;
	vector.y = a.y - dt.I.y;
	float kc = sqrt(vector.x * vector.x + vector.y * vector.y);
	return kc;
}
void tuongQuan(Diem2D a, DTron dt)
{
	if (doDai(a, dt) > dt.r)
		cout << "diem A nam ngoai duong tron" << endl;
	if(doDai(a, dt) == dt.r)
		cout << "diem A nam tren duong tron" << endl;
	if (doDai(a, dt) < dt.r)
		cout << "diem A nam trong duong tron" << endl;
}
void NhapArray(Array& ds)
{
	cout << "Nhap so luong tron ban muon them vao mang:", cin >> ds.n;
	for (int i = 0; i < ds.n; i++)
	{
		Nhap(ds.dsdt[i]);
		cout << endl;
	}
}
void XuatArray(Array ds)
{
	cout << "danh sach dtron cua ban: " << endl;
	for (int i = 0; i < ds.n; i++)
	{
		Xuat(ds.dsdt[i]);
	}
}
void Swap(DTron& a, DTron& b)
{
	DTron temp = a;
	a = b;
	b = temp;
}
void SortA(Array ds)
{
	for (int i = 0; i < ds.n - 1; i++)
	{
		for (int j = 1; j < ds.n; j++)
		{
			if (dienTich(ds.dsdt[i]) > dienTich(ds.dsdt[j]))
			{
				Swap(ds.dsdt[i], ds.dsdt[j]);
			}
		}
	}
}


