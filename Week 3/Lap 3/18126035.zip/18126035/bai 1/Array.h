#pragma once
#include<iostream>
#define Min(a,b) ((a)<(b) ? (a) : (b) )
using namespace std;

void Input(int* a, int rows, int columns);
void Output(int* a, int rows, int columns);
int Sum_PositiveNumbers(int* a, int rows, int columns);
bool isPrime(int n);
int countPrime(int* a, int rows, int columns);
int Max_Bien(int* a, int rows, int columns);
int Min_PositiveNumbers(int* a, int rows, int columns);
void rowNegativeNumber(int* a, int rows, int columns);
void rowEvenNumber(int* a, int rows, int columns);
int CntSaddleInMatrix(int* a, int nRow, int nCol);
bool KiemTraCoPhaiPhanTuHoangHau(int* a, int vtdong, int vtcot, int dong, int cot);
int DemSoLuongPhanTuHoangHau(int* a, int dong, int cot);