﻿#include"Array.h"


void Input(int* a, int rows, int columns)
{
	for (int i = 0; i < rows ; i++)
	{
		for (int j = 0; j < columns; j++)
		{
			cout << "a[" << i << "][" << j << "] = ";
			cin >> *(a + (i * rows + j));		// rows * i  + j
		}
	}
}

void Output(int* a, int rows, int columns)
{
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < columns; j++)
		{
			cout << "\t" << *(a + (i * rows + j));
		}
		cout << endl;
	}
}

int Sum_PositiveNumbers(int* a, int rows, int columns)
{
	int sum = 0;
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < columns; j++)
		{
			if (*(a + i * rows + j) > 0)
			{
				sum += *(a + i * rows + j);
			}

		}
	}
	return sum;
}
bool isPrime(int n)
{
	if (n <= 1)
	{
		return false;
	}
	for (int i = 2; i < n; i++)
	{
		if (n % i == 0) 
		{
			return false;
		}
	}
	return true;
}
int countPrime(int* a, int rows, int columns)
{
	int count = 0;
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < columns; j++)
		{
			if (isPrime(*(a + i * rows + j)) == true)
				count++;
		}
	}
	return count;

}
//so lon nhat cua bien matrix:)))
int Max_Bien(int* a, int rows, int columns)
{
	int max = *(a + 0);
	// first row
	for (int i = 0; i < columns; i++)
	{
		if (max < *(a+i) ) 
			max = *(a + i);
		if (max < *(a + i *(rows -1)));
			max = *(a + i * (rows - 1));
	}
	for (int j = 0; j < rows - 1; j++)
	{
		if (max < *(a + 0 * rows + j))
			max = *(a + 0 * rows + j);
		if (max < *(a + j * rows + columns - 1))
			max = *(a + j * rows + columns - 1);
	}
	return max;
}
int Min_PositiveNumbers(int* a, int rows, int columns)
{
	int min = *(a + 0);
	for (int i = 0; i < rows ; i++)
	{
		for (int j = 0; j < columns; j++)
		{
			if (min>*(a + (i * rows + j)))
			{
				min = *(a + (i * rows + j));
			}

		}
	}
	return min;
}
void rowNegativeNumber(int* a, int rows, int columns)
{
	int flag;
	for (int i = 0; i < rows; i++)
	{
		flag = 1;
		for (int j = 0; j < columns; j++)
		{
			if (*(a+i*rows+j) > 0)
			{
				flag = 0;
				break;
			}
		}
		if (flag == 1)
		{
			for (int j = 0; j < columns; j++)
			{
				cout<< *(a + (i * rows + j));
			}
		}
	}
}

void rowEvenNumber(int* a, int rows, int columns)
{
	int flag;
	for (int i = 0; i < rows; i++)
	{
		flag = 1;
		for (int j = 0; j < columns; j++)
		{
			if (*(a + (i * rows + j)) % 2 != 0)
			{
				flag = 0;
				break;
			}
		}
		if (flag == 1)
		{
			cout << "dong chan" << i;
		}
	}
}

int CntSaddleInMatrix(int *a, int nRow, int nCol)
{
	int iRow, iCol;
	int cnt = 0;
	int col;
	int max;
	int min;

	for (iRow = 0; iRow < nRow; iRow++)
	{
		max = *(a+ iRow);
		col = 0;
		for (iCol = 1; iCol < nCol; iCol++)
		{
			// Find maximum in a row
			if (max < *(a + iRow*nRow + iCol))
			{
				max = *(a + iRow * nRow + iCol);
				col = iCol;
			}
		}

		// Find minimum in a column col
		min = *(a+col);
		for (int i = 1; i < nRow; i++)
		{
			if (min > *(a+i*nRow + col))
			{
				min = *(a + i * nRow + col);
			}
		}

		// Compare maximum in row and minimm in column
		if (max == min)
		{
			cnt++;
		}
	}

	return cnt;
}

bool KiemTraCoPhaiPhanTuHoangHau(int *a, int vtdong, int vtcot, int dong, int cot)
{
	int x = *(a + dong * vtdong + vtcot);

	// kiểm tra dòng
	for (int i = 0; i < cot; i++)
	{
		if (*(a + vtdong * dong + i) > x)
		{
			return false;
		}
	}
	// kiểm tra cột
	for (int j = 0; j < dong; j++)
	{
		if (*(a + j * dong + vtcot) > x)
		{
			return false;
		}
	}
	//ktra duong cheo thu nhat
	int vtdong1 = vtdong + 1;
	int vtcot1 = vtcot + 1;
	while (vtcot1 + 1 < cot && vtdong1 < vtdong)
	{
		if (*(a + vtcot1 * dong + vtdong1) > x)
			return false;
		// tăng phải
		vtcot1++;
		vtdong1++;
	}
	vtdong1 = vtdong - 1;
	vtcot1 = vtcot - 1;
	while (vtcot1 - 1 >= 0 && vtdong1 >= 0)
	{
		if (*(a + vtcot1 * dong + vtdong1) > x)		
			return false;
		//giảm qua trái
		vtcot1--;
		vtdong1--;
	}
	// duong cheo thu 2
	vtdong1 = vtdong + 1;
	vtcot1 = vtcot - 1;
	while (vtcot1 - 1 >= 0 && vtdong1 < dong)
	{
		if (*(a + vtcot1 * dong + vtdong1) > x)
			return false;
		// tăng trái
		vtdong1++;
		vtcot1--;
	}
	vtdong1 = vtdong - 1;
	vtcot1 = vtcot + 1;

	while (vtdong1 - 1 >= 0 && vtcot1 < cot)
	{
		if (*(a + vtcot1 * dong + vtdong1) > x)
			return false;
		// giảm phải
		vtdong1--;
		vtcot1++;
	}
	return true;
}

int DemSoLuongPhanTuHoangHau(int *a, int dong, int cot)
{
	int dem = 0;
	for (int i = 0; i < dong; i++)
	{
		for (int j = 0; j < cot; j++)
		{
			if (KiemTraCoPhaiPhanTuHoangHau(a, i, j, dong, cot) == true)
			{
				dem++;
			}
		}
	}
	return dem;
}