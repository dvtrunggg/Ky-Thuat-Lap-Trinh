#include"Array.h"

int main()
{
	int rows, columns;
	cout << "size of rows: ", cin >> rows;
	cout << "size of column: ", cin >> columns;
	int* a;
	a = new int[rows * columns];
	Input(a, rows, columns);
	Output(a, rows, columns);
	
	/*cout<<" sum of array: "<<Sum_PositiveNumbers(a, rows, columns);
	cout << " the number of primes: " << countPrime(a, rows, columns);*/
	//cout << " max cua bien :" << Max_Bien(a, rows, columns);
	cout << " Min of Matrix: " << Min_PositiveNumbers(a, rows, columns) << endl;
	cout << CntSaddleInMatrix(a, rows, columns);
	
	delete[] a;
	return 0;

}