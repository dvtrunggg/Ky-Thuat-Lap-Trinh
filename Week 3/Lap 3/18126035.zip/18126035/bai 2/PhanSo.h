
// bai 2: struct phan so
#include<iostream>
#include<algorithm>
using namespace std;

typedef struct PhanSo
{
	int tu;
	int mau;
}PS;
PS *Nhap_PS();
void XuatPS(PS *p);
PS *CongPS(PS *ps1, PS *ps2);
int UCLN(int a, int b);
void rutGon(PS& p);
int soSanh(PS& a, PS& b);

