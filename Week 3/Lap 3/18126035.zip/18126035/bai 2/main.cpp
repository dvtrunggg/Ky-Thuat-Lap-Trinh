// bai 2
#include"PhanSo.h"

int main()
{
	PS *ps1;
	PS* ps2;
	ps1 = new PS;
	ps2 = new PS;
	if (ps1 == NULL || ps2 == NULL)
	{
		cout << "khong du bo nho" << endl;
		exit(0);
	}
	ps1 = Nhap_PS();
	cout << "ps1: ";
	XuatPS ( ps1 );
	ps2 = Nhap_PS();
	cout << "ps1: ";
	XuatPS ( ps2 );
	cout << "Cong 2 phan so: ";
	XuatPS(CongPS(ps1,ps2));
	cout << "Rut gon ps1: ";
	rutGon(*ps1);
	XuatPS(ps1);
	int check = soSanh(*ps1, *ps2);
	if (check == 1)
		cout << "ps1 > ps2";
	if (check == 0)
		cout << "ps1 = ps2";
	if (check == -1)
		cout << "ps1 < ps2";


	delete ps1;
	delete ps2;

	return 0;
}
