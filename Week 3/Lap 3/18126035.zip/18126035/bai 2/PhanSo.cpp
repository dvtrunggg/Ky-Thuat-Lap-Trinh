
//bai 2

#include"PhanSo.h"
PS * Nhap_PS()
{
	PS* p;
	p = new PS;
	if (p == NULL)
	{
		return NULL;
	}
	cout << "Nhap tu so:", cin >> p->tu;
	cout << "Nhap mau so:", cin >> p->mau;
	cout << endl;
	return p;
}
void XuatPS(PS *p)
{
	cout << p->tu << "/" << p->mau << endl;
}
PS *CongPS(PS *ps1, PS *ps2)
{
	PS *ketqua;
	ketqua = new PS;
	ketqua->tu = (ps1->tu * ps2->mau) + (ps2->tu * ps1->mau);
	ketqua->mau = ps1->mau * ps2->mau;
	return ketqua;
	
}
int UCLN(int a, int b) 
{
	
	if (a == 0 || b == 0) {
		return a + b;
	}
	while (a != b) {
		if (a > b) {
			a -= b; 
		}
		else {
			b -= a;
		}
	}
	return a; 
}

void rutGon(PS& p)
{
	int n = UCLN(p.tu, p.mau);
	p.tu = p.tu / n;
	p.mau = p.mau / n;
}
int soSanh(PS& a, PS& b)
{
	//quy dong tu
	a.tu = a.tu * b.mau;
	b.tu = b.tu * a.mau;
	if (a.tu > b.tu)
		return 1;
	if (a.tu == b.tu)
		return 0;
	if (a.tu < b.tu)
		return -1;
}