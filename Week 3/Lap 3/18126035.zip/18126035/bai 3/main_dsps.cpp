#include"dsps.h"
int main()
{
	DSPS ds;
	ds.soLuong = 3;
	Input_DS(ds);
	cout << "==================Phan so cua ban: =================" << endl;
	Output_DS(ds);
	XuatPS(sumOfArray(ds));
	cout << "cac ps toi gian:" << endl;
	XuatPsToiGian(ds);
	cout << endl << endl;
	PS* ps1;
	ps1 = new PS;
	ps1 = Nhap_PS();
	int check = Search(ds, *ps1);
	if (check = 1)
		cout << "ps ton tai" << endl;
	else
		cout << " ps ko ton tai" << endl;

	//giai phong
	for (int i = 0; i < ds.soLuong; i++)
	{
		delete ds.ds_ps[i];
	}
	return 0;
}
