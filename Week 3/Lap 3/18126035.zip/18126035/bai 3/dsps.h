
// bai 3: danh sach phan so
#pragma once
#include"PhanSo.h"
#include<iostream>
using namespace std;

struct DSPS {
	
	int soLuong;	// so luong phan so trong danh sach
	PS* ds_ps[100];
};

void Input_DS(DSPS& ds);
void Output_DS(DSPS ds);
PS* sumOfArray(DSPS ds);
void XuatPsToiGian(DSPS ds);
void Swap(PS& a, PS& b);
void SortA(DSPS ds);
int Search(DSPS ds, PS p);
