#include"dsps.h"

void Input_DS(DSPS& ds)
{
	for(int i = 0; i<ds.soLuong; i++)
	{
		PhanSo* p ;
		p = Nhap_PS();
		ds.ds_ps[i] = p;
	}

}
void Output_DS(DSPS ds) 
{
	for(int i = 0; i<ds.soLuong; i++)
	{
		XuatPS(ds.ds_ps[i]);
	}
}
// ham tinh tong array phan so 
PS* sumOfArray(DSPS ds)
{
	PS* sum = new PS;
	sum = ds.ds_ps[0];
	//sum = CongPS(sum, ds.ds_ps[1]);
	for (int i = 1; i < ds.soLuong ; i++)
	{
		sum = CongPS(sum, ds.ds_ps[i]);
	}
	return sum;
}
// xuat cac ps toi gian
void XuatPsToiGian(DSPS ds)
{
	for (int i = 0; i < ds.soLuong; i++)
	{
		rutGon(*ds.ds_ps[i]);
		
	}
	Output_DS(ds);
}
void Swap(PS& a, PS& b)
{
	PS temp = a;
	a = b;
	b = temp;
}
void SortA(DSPS ds)
{
	for (int i = 0; i < ds.soLuong - 1; i++)
	{
		for (int j = 1; j < ds.soLuong; j++)
		{
			if (soSanh(*ds.ds_ps[i], *ds.ds_ps[j]) == 1)
			{
				Swap(*ds.ds_ps[i], *ds.ds_ps[j]);
			}
		}
	}
}
int Search(DSPS ds, PS p)
{
	for (int i = 0; i < ds.soLuong ; i++)
	{
		if (p.tu == ds.ds_ps[i]->tu && p.mau == ds.ds_ps[i]->mau)
		{
			return 1;
		}
	}
	return 0;
}